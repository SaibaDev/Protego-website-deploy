document.addEventListener('DOMContentLoaded', function() {
    console.log("Blacklisted script loaded");

    // Function to display blacklisted URLs
    function displayBlacklistedURLs(blacklist) {
        var blacklistContent = document.getElementById('blacklistContent');
        blacklistContent.innerHTML = ""; // Clear previous content

        if (blacklist.length === 0) {
            blacklistContent.textContent = "No blacklisted URLs";
        } else {
            blacklist.forEach(function(url) {
                var listItem = document.createElement('li');
                listItem.textContent = url;
                
                var removeButton = document.createElement('button');
                removeButton.textContent = "Remove";
                removeButton.addEventListener('click', function() {
                    removeFromBlacklist(url);
                    listItem.remove();
                });

                listItem.appendChild(removeButton);
                blacklistContent.appendChild(listItem);
            });
        }
    }

    // Function to get blacklist from local storage
    function getBlacklistFromStorage() {
        chrome.storage.local.get('blacklist', function(data) {
            var blacklist = data.blacklist || [];
            displayBlacklistedURLs(blacklist);
        });
    }

    // Call the function to display blacklisted URLs when the DOM is loaded
    getBlacklistFromStorage();

    // Function to remove URL from blacklist
    function removeFromBlacklist(url) {
        chrome.storage.local.get('blacklist', function(data) {
            var blacklist = data.blacklist || [];
            var index = blacklist.indexOf(url);
            if (index !== -1) {
                blacklist.splice(index, 1);
                chrome.storage.local.set({ 'blacklist': blacklist });
            }
        });
    }
});
