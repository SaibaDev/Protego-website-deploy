Protego paspasan  <br>
ilang % na kaya?

