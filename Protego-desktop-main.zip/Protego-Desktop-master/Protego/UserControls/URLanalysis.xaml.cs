﻿using System.Windows.Controls;
using Accord.IO;
using System.Windows;

namespace Protego.UserControls
{
    /// <summary>
    /// Interaction logic for URLanalysis.xaml
    /// </summary>
    public partial class URLanalysis : UserControl
    {
       
        public URLanalysis()
        {
            InitializeComponent();

           
        }
    }
}
