function predict() {
    
    var urlInput = document.getElementById("urlInput").value;

    var randomNumber = Math.floor(Math.random() * 100) + 1;

   
    var isOdd = randomNumber % 2 !== 0;

    
    var resultElement = document.getElementById("result");
    resultElement.innerHTML = "Generated Number: " + randomNumber + "<br>";

    if (isOdd) {
        resultElement.innerHTML += "The URL '" + urlInput + "' is MALICIOUS!";
    } else {
        resultElement.innerHTML += "The URL '" + urlInput + "' is NOT MALICIOUS.";
    }
}
